﻿namespace homework4_2
{
    partial class SearchResult
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchResult));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.inputMinPriceTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.inputMaxPriceTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.SearchByComboBox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.inputUsernameTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.SearchButton = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(565, 488);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // inputMinPriceTextBox
            // 
            this.inputMinPriceTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.inputMinPriceTextBox.DefaultText = "";
            this.inputMinPriceTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.inputMinPriceTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.inputMinPriceTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.inputMinPriceTextBox.DisabledState.Parent = this.inputMinPriceTextBox;
            this.inputMinPriceTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.inputMinPriceTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.inputMinPriceTextBox.FocusedState.Parent = this.inputMinPriceTextBox;
            this.inputMinPriceTextBox.Font = new System.Drawing.Font("Franklin Gothic Medium", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputMinPriceTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.inputMinPriceTextBox.HoverState.Parent = this.inputMinPriceTextBox;
            this.inputMinPriceTextBox.Location = new System.Drawing.Point(73, 110);
            this.inputMinPriceTextBox.Name = "inputMinPriceTextBox";
            this.inputMinPriceTextBox.PasswordChar = '\0';
            this.inputMinPriceTextBox.PlaceholderText = "Min Price：";
            this.inputMinPriceTextBox.SelectedText = "";
            this.inputMinPriceTextBox.ShadowDecoration.Parent = this.inputMinPriceTextBox;
            this.inputMinPriceTextBox.Size = new System.Drawing.Size(177, 43);
            this.inputMinPriceTextBox.TabIndex = 14;
            // 
            // inputMaxPriceTextBox
            // 
            this.inputMaxPriceTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.inputMaxPriceTextBox.DefaultText = "";
            this.inputMaxPriceTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.inputMaxPriceTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.inputMaxPriceTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.inputMaxPriceTextBox.DisabledState.Parent = this.inputMaxPriceTextBox;
            this.inputMaxPriceTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.inputMaxPriceTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.inputMaxPriceTextBox.FocusedState.Parent = this.inputMaxPriceTextBox;
            this.inputMaxPriceTextBox.Font = new System.Drawing.Font("Franklin Gothic Medium", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputMaxPriceTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.inputMaxPriceTextBox.HoverState.Parent = this.inputMaxPriceTextBox;
            this.inputMaxPriceTextBox.Location = new System.Drawing.Point(73, 185);
            this.inputMaxPriceTextBox.Name = "inputMaxPriceTextBox";
            this.inputMaxPriceTextBox.PasswordChar = '\0';
            this.inputMaxPriceTextBox.PlaceholderText = "Max Price：";
            this.inputMaxPriceTextBox.SelectedText = "";
            this.inputMaxPriceTextBox.ShadowDecoration.Parent = this.inputMaxPriceTextBox;
            this.inputMaxPriceTextBox.Size = new System.Drawing.Size(177, 43);
            this.inputMaxPriceTextBox.TabIndex = 13;
            // 
            // SearchByComboBox
            // 
            this.SearchByComboBox.BackColor = System.Drawing.Color.Transparent;
            this.SearchByComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.SearchByComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SearchByComboBox.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SearchByComboBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SearchByComboBox.FocusedState.Parent = this.SearchByComboBox;
            this.SearchByComboBox.Font = new System.Drawing.Font("Franklin Gothic Medium", 10F, System.Drawing.FontStyle.Bold);
            this.SearchByComboBox.ForeColor = System.Drawing.Color.Indigo;
            this.SearchByComboBox.HoverState.Parent = this.SearchByComboBox;
            this.SearchByComboBox.ItemHeight = 30;
            this.SearchByComboBox.Items.AddRange(new object[] {
            "By name",
            "By price"});
            this.SearchByComboBox.ItemsAppearance.Parent = this.SearchByComboBox;
            this.SearchByComboBox.Location = new System.Drawing.Point(73, 353);
            this.SearchByComboBox.Name = "SearchByComboBox";
            this.SearchByComboBox.ShadowDecoration.Parent = this.SearchByComboBox;
            this.SearchByComboBox.Size = new System.Drawing.Size(177, 36);
            this.SearchByComboBox.TabIndex = 12;
            // 
            // inputUsernameTextBox
            // 
            this.inputUsernameTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.inputUsernameTextBox.DefaultText = "";
            this.inputUsernameTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.inputUsernameTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.inputUsernameTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.inputUsernameTextBox.DisabledState.Parent = this.inputUsernameTextBox;
            this.inputUsernameTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.inputUsernameTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.inputUsernameTextBox.FocusedState.Parent = this.inputUsernameTextBox;
            this.inputUsernameTextBox.Font = new System.Drawing.Font("Franklin Gothic Medium", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputUsernameTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.inputUsernameTextBox.HoverState.Parent = this.inputUsernameTextBox;
            this.inputUsernameTextBox.Location = new System.Drawing.Point(73, 263);
            this.inputUsernameTextBox.Name = "inputUsernameTextBox";
            this.inputUsernameTextBox.PasswordChar = '\0';
            this.inputUsernameTextBox.PlaceholderText = "User Name：";
            this.inputUsernameTextBox.SelectedText = "";
            this.inputUsernameTextBox.ShadowDecoration.Parent = this.inputUsernameTextBox;
            this.inputUsernameTextBox.Size = new System.Drawing.Size(177, 43);
            this.inputUsernameTextBox.TabIndex = 11;
            // 
            // SearchButton
            // 
            this.SearchButton.BackColor = System.Drawing.Color.Transparent;
            this.SearchButton.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.SearchButton.CheckedState.Parent = this.SearchButton;
            this.SearchButton.HoverState.ImageSize = new System.Drawing.Size(30, 30);
            this.SearchButton.HoverState.Parent = this.SearchButton;
            this.SearchButton.Image = ((System.Drawing.Image)(resources.GetObject("SearchButton.Image")));
            this.SearchButton.ImageRotate = 0F;
            this.SearchButton.ImageSize = new System.Drawing.Size(30, 30);
            this.SearchButton.Location = new System.Drawing.Point(13, 3);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.PressedState.ImageSize = new System.Drawing.Size(30, 30);
            this.SearchButton.PressedState.Parent = this.SearchButton;
            this.SearchButton.Size = new System.Drawing.Size(54, 76);
            this.SearchButton.TabIndex = 10;
            this.SearchButton.UseTransparentBackground = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.inputMinPriceTextBox);
            this.guna2Panel1.Controls.Add(this.SearchByComboBox);
            this.guna2Panel1.Controls.Add(this.inputMaxPriceTextBox);
            this.guna2Panel1.Controls.Add(this.inputUsernameTextBox);
            this.guna2Panel1.Controls.Add(this.SearchButton);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel1.Location = new System.Drawing.Point(509, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(292, 488);
            this.guna2Panel1.TabIndex = 15;
            // 
            // SearchResult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.GhostWhite;
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "SearchResult";
            this.Size = new System.Drawing.Size(801, 488);
            this.guna2Panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Guna.UI2.WinForms.Guna2TextBox inputMinPriceTextBox;
        private Guna.UI2.WinForms.Guna2TextBox inputMaxPriceTextBox;
        private Guna.UI2.WinForms.Guna2ComboBox SearchByComboBox;
        private Guna.UI2.WinForms.Guna2TextBox inputUsernameTextBox;
        private Guna.UI2.WinForms.Guna2ImageButton SearchButton;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
    }
}
